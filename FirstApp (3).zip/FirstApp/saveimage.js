document.addEventListener('DOMContentLoaded', () => {
    const logoDisplay = document.getElementById('logoDisplay');
    const backButton = document.getElementById('backButton');

    // Retrieve saved logo settings
    const savedName = localStorage.getItem('logoName') || 'Your Name';
    const savedFont = localStorage.getItem('logoFont') || 'Arial';
    const savedColor = localStorage.getItem('logoColor') || '#000000';
    const savedFontSize = localStorage.getItem('logoFontSize') || '36';
    const savedTextShadow = localStorage.getItem('logoTextShadow') || 'none';

    // Apply settings to logo display
    logoDisplay.textContent = savedName;
    logoDisplay.style.fontFamily = savedFont;
    logoDisplay.style.color = savedColor;
    logoDisplay.style.fontSize = `${savedFontSize}px`;
    logoDisplay.style.textShadow = savedTextShadow;

    backButton.addEventListener('click', () => {
        window.location.href = 'logo-designer.html';
    });
});
