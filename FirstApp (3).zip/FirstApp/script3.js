function showTutorial(type) {
    const tutorial = document.getElementById('tutorial');
    if (type === 'basic') {
        tutorial.innerHTML = `
            <h3>Basic Strokes</h3>
            <p>Practice these basic strokes to start your calligraphy journey.</p>
            <img src="basicstoke.jpg" alt="Basic Strokes" height="300px" width="300px">
        `;
    } if (type === 'alphabet') {
        tutorial.innerHTML = `
            <h3>Alphabet</h3>
            <p>Learn how to write each letter of the alphabet in calligraphy.</p>
            <img src="alphabet.jpg" alt="Calligraphy Alphabet" height="300px" width="300px">
        `;
    } if (type === 'words') {
        tutorial.innerHTML = `
            <h3>Words</h3>
            <p>Practice writing words in calligraphy to improve your skills.</p>
            <img src="words.jpg" alt="Calligraphy Words" height="300px" width="300px">
        `;
    }
}

const canvas = document.getElementById('practiceCanvas');
const ctx = canvas.getContext('2d');
let painting = false;

canvas.addEventListener('mousedown', startPosition);
canvas.addEventListener('mouseup', endPosition);
canvas.addEventListener('mousemove', draw);

function startPosition(e) {
    painting = true;
    draw(e);
}

function endPosition() {
    painting = false;
    ctx.beginPath();
}

function draw(e) {
    if (!painting) return;
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.strokeStyle = 'black';
    
    ctx.lineTo(e.clientX - canvas.offsetLeft, e.clientY - canvas.offsetTop);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(e.clientX - canvas.offsetLeft, e.clientY - canvas.offsetTop);
}

function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}
