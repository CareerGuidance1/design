document.addEventListener('DOMContentLoaded', () => {
    const logoNameInput = document.getElementById('logoName');
    const fontSelect = document.getElementById('fontSelect');
    const colorPicker = document.getElementById('colorPicker');
    const fontSizeInput = document.getElementById('fontSize');
    const textShadowInput = document.getElementById('textShadow');
    const logoDisplay = document.getElementById('logoDisplay');
    const saveButton = document.getElementById('saveButton');

    function updateLogo() {
        logoDisplay.textContent = logoNameInput.value || 'Your Name';
        logoDisplay.style.fontFamily = fontSelect.value;
        logoDisplay.style.color = colorPicker.value;
        logoDisplay.style.fontSize = `${fontSizeInput.value}px`;
        logoDisplay.style.textShadow = textShadowInput.value;
    }

    logoNameInput.addEventListener('input', updateLogo);
    fontSelect.addEventListener('change', updateLogo);
    colorPicker.addEventListener('input', updateLogo);
    fontSizeInput.addEventListener('input', updateLogo);
    textShadowInput.addEventListener('input', updateLogo);

    saveButton.addEventListener('click', () => {
        localStorage.setItem('logoName', logoNameInput.value);
        localStorage.setItem('logoFont', fontSelect.value);
        localStorage.setItem('logoColor', colorPicker.value);
        localStorage.setItem('logoFontSize', fontSizeInput.value);
        localStorage.setItem('logoTextShadow', textShadowInput.value);
        window.location.href = 'saveimage.html';
    });

    updateLogo();
});
